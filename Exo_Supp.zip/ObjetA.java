import java.util.Objects;

public class ObjetA {
    private int num;
    private String nom;

    public ObjetA(int num, String nom) {
        this.num = num;
        this.nom = nom;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ObjetA objetA = (ObjetA) o;
        return Objects.equals(nom, objetA.nom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nom);
    }

    @Override
    public String toString() {
        return nom;
    }
}
