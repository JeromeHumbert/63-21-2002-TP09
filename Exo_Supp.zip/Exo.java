import java.util.ArrayList;
import java.util.Iterator;

public class Exo {
    private static ArrayList<ObjetA> objets = new ArrayList<>();

    private static void supprimerSalutation(String nom){
		/** L'objectif est de supprimer toutes les instances de ObjetA contenues 
		    dans l'arraylist objets qui sont equals à l'objet aSupprimer.
		
			La méthode equals est déjà implémentée dans la classe ObjetA, 
			la seule chose demandée est la suppression au moyen d'une boucle.
			
			En commentaires ci-dessous, deux exemples de code que vous pouvez décommenter pour voir les résultats de chacuns.
			Les deux codes ne font pas le boulot demandé complètement.
			
		*/

        ObjetA aSupprimer = new ObjetA(1,nom);
        
         /*
            Avec ce code, erreur ConcurrentModification

        for (ObjetA o : objets) {
            if (o.equals(aSupprimer)){
                objets.remove(o);
            }
        }*/

        /*
            Avec ce code il reste un Hello à l'affichage

        for (int i = 0; i < objets.size(); i++) {
            Object o = objets.get(i);
            if (o.equals(aSupprimer)){
                objets.remove(objets.get(i));
            }
        }*/
    }

    private static void afficherListe(){
        for (ObjetA o: objets) {
            System.out.println(o);
        }
    }

    public static void main(String[] args) {
        objets.add(new ObjetA(1,"Salut"));
        objets.add(new ObjetA(2,"Salut"));
        objets.add(new ObjetA(3,"Salut"));
        objets.add(new ObjetA(4,"Hello"));
        objets.add(new ObjetA(5,"Hello"));
        objets.add(new ObjetA(6,"Hello"));
        objets.add(new ObjetA(7,"Bonjour"));
        objets.add(new ObjetA(8,"Bonjour"));
        objets.add(new ObjetA(9,"Bonjour"));
        objets.add(new ObjetA(10,"Hola"));
        objets.add(new ObjetA(11,"Hola"));
        objets.add(new ObjetA(12,"Hola"));

        supprimerSalutation("Hello");
        afficherListe();
    }
}
